package hmu.netmpea.services;

import org.rosuda.REngine.REXP;

/**
 * R结果解析方法
 * 
 * 将R生成的结果解析为可以在网页中显示的简单数据结构（本系统采用数组，也可以使用Map，List等）
 * 
 * @author cyp
 *
 */
public interface RResultParseService {

	/**
	 * 将结果解析成二维数组。主要用于显示MetabolitePriori程序产生的结果矩阵
	 * @param exp
	 * @return
	 * @throws Exception
	 */
	public String[][] parseToTable(REXP exp) throws Exception;
	
	/**
	 * 将结果解析成一维数组。主要用于显示MetabolitePriori程序产生的各种辅助列表，如disease列表等。
	 * @param exp
	 * @return
	 * @throws Exception
	 */
	public String[] parseToArray(REXP exp) throws Exception;
}
