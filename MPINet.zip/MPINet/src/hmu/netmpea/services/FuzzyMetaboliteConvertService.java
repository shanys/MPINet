package hmu.netmpea.services;

import java.util.List;

import org.compass.core.CompassHit;

public interface FuzzyMetaboliteConvertService {

	public List<CompassHit> find(String name);
}
