package hmu.netmpea.services;

import org.springframework.web.multipart.MultipartFile;

/**
 * 参数转换接口
 * 
 * 用于将Web页面传入的字符串/文件参数转换为数组
 * 
 * @author cyp
 *
 */
public interface ParameterConvertService {

	public String[] convert(String input) throws Exception;
	
	public String[] convert(MultipartFile input) throws Exception;
}
