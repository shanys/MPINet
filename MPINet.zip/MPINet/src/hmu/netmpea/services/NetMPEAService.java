package hmu.netmpea.services;

/**
 * NetMPEA 调用接口
 * 
 * 用于调用NetMPEA包。
 * 主要方法为execute方法。其参数与R中参数基本一致，在调用前，需要根据参数传入情况自组织实际传参。
 * 
 * @author yhx
 *
 */
public interface NetMPEAService {

	public String[][] execute(String[] risk, String pathType, String method, int annlim, int bglim) throws Exception;

}
