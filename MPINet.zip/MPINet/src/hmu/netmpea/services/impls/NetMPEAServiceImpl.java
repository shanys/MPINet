package hmu.netmpea.services.impls;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.rosuda.REngine.REXP;
import org.rosuda.REngine.Rserve.RConnection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hmu.netmpea.services.RResultParseService;
import hmu.netmpea.services.NetMPEAService;

@Service
public class NetMPEAServiceImpl implements NetMPEAService {
	
	@Autowired
	private RConnection connection;
	
	@Autowired
	private RResultParseService resultParseService;
	
	@PostConstruct
	public void init() throws Exception {
		if(connection != null)
			connection.voidEval("library(\"MPINet\")");
	}
	
	@PreDestroy
	public void finalize() throws Exception {
	}
	
	@Override
	public String[][] execute(String[] risk, String pathType, String method, int annlim, int bglim) throws Exception{
		//set parameters
		//此处使用assign方式，也可以使用voidEval方式，相比之下，使用assign方式可以少很多字符串拼接，防止出错
		connection.assign("risk", risk);
		//connection.voidEval("risk<-as.character(risk[[1]])");
		connection.voidEval("pss<-getPSS(risk,plot=F)");
		connection.assign("pathType0", pathType);
		connection.assign("method0", method);
		
		//build command
		//构造command。
		String command = 
				"anncpdpre<-identifypathway(" +
						"risk," +
						"pss," +
						"pathType=pathType0," +
						"method=method0," +
						"annlim=" + annlim + "," +
						"bglim=" + bglim;
		command+=")";
		//compute
		connection.eval(command);
		String convertStr = 
			"result<-printGraph(" +
				"anncpdpre," +
				"pathType=pathType0," +
				"detail=TRUE," +
				"method=method0" ;
		convertStr+=")";
		REXP exp = connection.eval(convertStr);
		String[][] result = resultParseService.parseToTable(exp);
		
		return result;
	}
	
}
