package hmu.netmpea.services.impls;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import hmu.netmpea.services.ParameterConvertService;

@Service
public class ParameterConvertServiceImpl implements ParameterConvertService {

	private static Logger logger = LoggerFactory.getLogger(ParameterConvertService.class);
	
	@Override
	public String[] convert(String input) throws Exception {
		String[] output = input.split("\r\n|\n\r|\r|\n");
		logger.debug("[Convert result from string]"+Arrays.toString(output));
		return output;
	}

	@Override
	public String[] convert(MultipartFile input) throws Exception {
		List<String> outputList = new LinkedList<String>();
		BufferedReader reader = new BufferedReader(new InputStreamReader(input.getInputStream()));
		String line = reader.readLine();
		while(line!=null && line.trim().length()>0) {
			outputList.add(line);
			line = reader.readLine();
		}
		String[] output = outputList.toArray(new String[0]);
		logger.debug("[Convert result from file]"+Arrays.toString(output));
		
		return output;
	}

}
