package hmu.netmpea.services.impls;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.compass.core.CompassHit;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import hmu.netmpea.osem.Metabolite;
import hmu.netmpea.services.FuzzyMetaboliteConvertService;
import hmu.netmpea.services.IDConvertService;

@Service
public class IDConvertServiceImpl implements IDConvertService {
	
	@Autowired 
	private FuzzyMetaboliteConvertService fuzzyMetaboliteConvertService;
	
	private static Map<String, String> smap = null;
	private static Map<String, String> keggmap = null;
	private static Map<String, String> chebimap = null;
	private static Map<String, String> chemblmap = null;
	private static Map<String, String> hmdbmap = null;
	private static Map<String, String> metaboliteNameMap = null;
	
	private void initMap(int mapId, int keyIdx, int valueIdx) throws Exception {
		Map<String, String> map = null;
		switch(mapId) {
		case 1:
			if(smap != null) return;
			smap = new HashMap<String, String>();
			map = smap;
			break;
		case 2:
			if(keggmap != null) return;
			keggmap = new HashMap<String, String>();
			map = keggmap;
			break;
		case 3:
			if(chebimap != null) return;
			chebimap = new HashMap<String, String>();
			map = chebimap;
			break;
		case 4:
			if(chemblmap != null) return;
			chemblmap = new HashMap<String, String>();
			map = chemblmap;
			break;
		case 5:
			if(hmdbmap != null) return;
			hmdbmap = new HashMap<String, String>();
			map = hmdbmap;
			break;
		case 6:
			if(metaboliteNameMap != null) return;
			metaboliteNameMap = new HashMap<String, String>();
			map = metaboliteNameMap;
			break;
		}
	
		Resource resource = new ClassPathResource("IDmapresult.txt");
		BufferedReader br = new BufferedReader(new InputStreamReader(resource.getInputStream()));
		
		String line = br.readLine();
		while(line != null && line.trim().length()>0) {
			String[] mapArray = line.split("\t");
			if(mapArray[keyIdx] != null && mapArray[keyIdx].trim().length()>0){
				String[] sArr = mapArray[keyIdx].split(";");
				for(int i=0; i<sArr.length; i++){
					if(keyIdx == 6)
						map.put(sArr[i].toLowerCase(), mapArray[valueIdx]);
					else
						map.put(sArr[i], mapArray[valueIdx]);
				}
			}
			line = br.readLine();
		}
		br.close();
	}
	
	public ArrayList<String> convert(String[] risk, String dataType) throws Exception{
		Resource resource = new ClassPathResource("IDmapresult.txt");
		BufferedReader br = new BufferedReader(new InputStreamReader(resource.getInputStream()));
		ArrayList<String> idlist = new ArrayList<String>();
		//SID
		if(dataType.equals("SID")){
			initMap(1, 1, 0);
			for(String s : risk){
				if(smap.get(s) != null){
					idlist.add(s+"\t"+smap.get(s));
				}else{
					idlist.add(s+"\t"+"NA");
					}
			}
		}
		//KEGGID
		if(dataType.equals("KEGGID")){
			initMap(2, 2, 0);
			for(String s : risk){
				if(keggmap.get(s) != null){
					idlist.add(s+"\t"+keggmap.get(s));
				}else{
					idlist.add(s+"\t"+"NA");
					}
			}
		}
		//CHEBIID
		if(dataType.equals("CHEBIID")){
			initMap(3, 3, 0);			
			for(String s : risk){
				if(chebimap.get(s) != null){
					idlist.add(s+"\t"+chebimap.get(s));
				}else{
					idlist.add(s+"\t"+"NA");
					}
			}
		}
		//CHEMBLID
		if(dataType.equals("CHEMBLID")) {
			initMap(4, 4, 0);
			for(String s : risk){
				if(chemblmap.get(s) != null){
					idlist.add(s+"\t"+chemblmap.get(s));
				}else{
					idlist.add(s+"\t"+"NA");
					}
			}
		}
		//HMDBID
		if(dataType.equals("HMDBID")) {
			initMap(5, 5, 0);
			for(String s : risk){
				if(hmdbmap.get(s) != null){
					idlist.add(s+"\t"+hmdbmap.get(s));
				}else{
					idlist.add(s+"\t"+"NA");
					}
			}
		}
		
		br.close();
		return idlist;
	}

	@Override
	public String[][] fuzzyFind(String[] risk) throws Exception {
		initMap(6, 6, 0);
		String[][] ret = new String[risk.length][4];//risk[i],模糊查找的最佳结果，相应的CID，是否有view
		for(int i=0; i<ret.length; i++) {
			if(metaboliteNameMap.containsKey(risk[i].toLowerCase())) {//full mapping
				//ret[i] = new String[]{String.format("%s;%s;%s;%s", risk[i],  risk[i],  metaboliteNameMap.get(risk[i]), null)};
				ret[i][0] = risk[i];
				ret[i][1] = risk[i];
				ret[i][2] = metaboliteNameMap.get(risk[i].toLowerCase());
				ret[i][3] = "1";  //完全匹配
			} else {//fuzzy mapping
				List<CompassHit> fuzzyResults = fuzzyMetaboliteConvertService.find(risk[i]);
				//ret[i] = new String[fuzzyResults.size()];
				if(fuzzyResults.size()>0){
					CompassHit hit = fuzzyResults.get(0);
					Metabolite m = (Metabolite) hit.getData();
					//ret[i][j] = String.format("%s;%s;%.4f", m.getMetaboliteId(), m.getName(), hit.getScore());
					ret[i][0] = risk[i];
					ret[i][1] = m.getName();
					ret[i][2] = m.getMetaboliteId();
					ret[i][3] = "2";//有多个匹配值
				}else{
					ret[i][0] = risk[i];
					ret[i][1] = null;
					ret[i][2] = null;
					ret[i][3] = "0";//没有匹配上的值
				}

			}
		}
		return ret;
	}
	
	public String[][] fuzzyDetail(String risk) throws Exception{
		initMap(6, 6, 0);
		List<CompassHit> fuzzyResults = fuzzyMetaboliteConvertService.find(risk);
		int size = Math.min(fuzzyResults.size(), 15);
		String[][] ret = new String[size][3];//risk，模糊查找匹配值，相应CID
			{//fuzzy mapping
				for(int i=0; i<size ; i++){
					CompassHit hit = fuzzyResults.get(i);
					Metabolite m = (Metabolite) hit.getData();
					ret[i][0] = risk;
					ret[i][1] = m.getName();
					ret[i][2] = m.getMetaboliteId();
				}
			}
		return ret;
	}
	
	@Override
	public String[] listToArray(ArrayList<String> idlist) throws Exception{
		ArrayList<String> riskList = new ArrayList<String>();
		for(String risk : idlist){
			String[] line = risk.split("\t");
			if (line[1] != null && !line[1].equals("NA") && line[1].length()>0 ){
				riskList.add(line[1]);
			}
		}
		return riskList.toArray(new String[0]);
	}
}
