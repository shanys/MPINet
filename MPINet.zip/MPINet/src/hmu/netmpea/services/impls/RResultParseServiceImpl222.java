package hmu.netmpea.services.impls;

import java.util.Vector;

import org.apache.commons.lang.StringUtils;
import org.rosuda.REngine.REXP;
import org.rosuda.REngine.REXPDouble;
import org.rosuda.REngine.REXPFactor;
import org.rosuda.REngine.REXPGenericVector;
import org.rosuda.REngine.REXPInteger;
import org.rosuda.REngine.REXPString;
import org.rosuda.REngine.RList;
import hmu.netmpea.services.RResultParseService;

//@Service
public class RResultParseServiceImpl222 implements RResultParseService {

	//结果集是一个list，每条记录包含16个字段。
	@Override
	public String[][] parseToTable(REXP exp) throws Exception {

		String[][] data = null;
		RList result = exp.asList();
		Object[] rows = result.toArray();
		
		data = new String[rows.length+1][];
		
		for(int i=0; i<rows.length; i++) {
			REXPGenericVector vector = (REXPGenericVector) rows[i];
			RList r = vector.asList();
			if(i==0) {
				@SuppressWarnings("rawtypes")
				Vector names = r.names;
				data[0] = new String[names.size()];
				for(int j=0; j<names.size(); j++) {
					data[0][j] = names.get(j).toString();
				}
			}
			Object[] columns = r.toArray();
			data[i+1] = new String[columns.length];
			for(int j=0; j<columns.length; j++) {
				
				Object col = columns[j];
				if(col instanceof REXPString) {
					String value = StringUtils.join(((REXPString)col).asStrings(),";");
					data[i+1][j] = value;
				}else if(col instanceof REXPInteger) {
					String value = StringUtils.join(((REXPInteger)col).asStrings(),";");
					data[i+1][j] = value;
				}else if(col instanceof REXPDouble) {
					String value = StringUtils.join(((REXPDouble)col).asStrings(),";");
					data[i+1][j] = value;
				}else if(col instanceof REXPFactor) {
					String value = StringUtils.join(((REXPFactor)col).asStrings(),";");
					data[i+1][j] = value;
				}
				else {
					throw new IllegalStateException(col.getClass().toString());
				}
			}
		}
		//System.out.println("-----------------------------------------------");
		//System.out.println(Arrays.deepToString(data));
		return data;
	}

	@Override
	public String[] parseToArray(REXP exp) throws Exception {
		if(exp instanceof REXPFactor) {
			return ((REXPFactor)exp).asFactor().asStrings();
		} else if(exp instanceof REXPString) {  
			return ((REXPString)exp).asStrings();
		} else {
			throw new IllegalStateException("Unhandled REXP type: \n"+exp);
		}
	}

}
