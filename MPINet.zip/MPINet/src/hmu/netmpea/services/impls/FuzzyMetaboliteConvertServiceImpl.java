package hmu.netmpea.services.impls;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.compass.core.CompassDetachedHits;
import org.compass.core.CompassHit;
import org.compass.core.CompassQueryBuilder;
import org.compass.core.CompassSession;
import org.compass.core.CompassTransaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hmu.netmpea.services.FuzzyMetaboliteConvertService;

@Service
public class FuzzyMetaboliteConvertServiceImpl implements
		FuzzyMetaboliteConvertService {

	//public static float SIMILARITY_RATE = 0.8f;    设定阈值后，名字短的不容易匹配，所以取全部模糊匹配的值，显示前5个。
	
	@Autowired CompassSession session;
	
	@Override
	public List<CompassHit> find(String name) {
		CompassTransaction tr = session.beginTransaction();
		
		List<CompassHit> list = new LinkedList<CompassHit>();
		
		CompassQueryBuilder cqb = session.queryBuilder();
		//CompassDetachedHits hits = cqb.fuzzy("name", name, SIMILARITY_RATE).hits().detach();
		CompassDetachedHits hits = cqb.fuzzy("name", name).hits().detach();
		Iterator<CompassHit> itor = hits.iterator();
		while(itor.hasNext()) {
			list.add(itor.next());
		}
		
		tr.commit();
		
		return list;
	}
}
