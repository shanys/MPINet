package hmu.netmpea.services.impls;

import org.rosuda.REngine.REXP;
import org.rosuda.REngine.REXPDouble;
import org.rosuda.REngine.REXPFactor;
import org.rosuda.REngine.REXPInteger;
import org.rosuda.REngine.REXPString;
import org.rosuda.REngine.RList;
import org.springframework.stereotype.Service;

import hmu.netmpea.services.RResultParseService;

@Service
public class RResultParseServiceImpl implements RResultParseService {

	@Override
	public String[][] parseToTable(REXP exp) throws Exception {

		RList result = exp.asList();
		// fetch column names
		String[] colNames = result.keys();
		//SZG增加对空值情况的处理；
		if(colNames==null){
			String[][] data = {{"pathwayName","annComponentRatio","annBgRatio","pvalue","fdr"}};
			return data;
		}
		//SZG
		int colCount = colNames.length;
		
		// fetch data by column		
		REXP[] colValues = new REXP[colCount];
		for (int i = 0; i < colValues.length; i++) {
			colValues[i] = result.at(colNames[i]);
		}
		//fetch row number
		int rowCount = result.at(colNames[1]).length();
		String[][] data = new String[rowCount+1][colCount+1];
		
		for(int i=0; i< colCount; i++) {
			data[0][i] = colNames[i];
			//System.out.print(data[0][i]);
			//System.out.print("\t");
		}
		for(int j=1; j<= rowCount; j++) {
			for(int i=0; i< colCount; i++) {
				REXP tmp = colValues[i];
				if(tmp instanceof REXPFactor) {//将因子类型的colValues转换为字符串数组；
					data[j][i] = ((REXPFactor)tmp).asFactor().asStrings()[j-1];
					//System.out.print(data[j][i]);
					//System.out.print("\t");
				}else if(tmp instanceof REXPString){//将String类型的colValues转换为字符串数组；
					data[j][i] = ((REXPString)tmp).asStrings()[j-1];
				}else if(tmp instanceof REXPInteger) {//将Integer类型的colvalues转换为字符串数组；
					data[j][i] = Integer.toString(((REXPInteger)tmp).asIntegers()[j-1]);
				} else if(tmp instanceof REXPDouble) {//将Double类型的colValues转换为字符串数组；
					data[j][i] = String.format("%.4e", ((REXPDouble)tmp).asDoubles()[j-1]);
				} else {
					throw new IllegalStateException("Unhandled REXP type: \n"+tmp);
				}
				
			}
		}
		//System.out.println("-----------------");
		//System.out.println(Arrays.deepToString(data));
		return data;
	}

	@Override
	public String[] parseToArray(REXP exp) throws Exception {
		if(exp instanceof REXPFactor) {
			return ((REXPFactor)exp).asFactor().asStrings();
		} else if(exp instanceof REXPString) {  
			return ((REXPString)exp).asStrings();
		} else {
			throw new IllegalStateException("Unhandled REXP type: \n"+exp);
		}
	}

}
