package hmu.netmpea.services;

import java.util.ArrayList;

public interface IDConvertService {
	
	public ArrayList<String> convert(String[] risk, String dataType) throws Exception;
	
	//查找完全匹配或者最佳匹配(1个值)显示到mapping页面
	public String[][] fuzzyFind(String[] risk) throws Exception;
	
	//查找当前metaboliteName的模糊匹配的前10个值，显示到details页面
	public String[][] fuzzyDetail(String risk) throws Exception;
	
	public String[] listToArray(ArrayList<String> idlist) throws Exception;
}
