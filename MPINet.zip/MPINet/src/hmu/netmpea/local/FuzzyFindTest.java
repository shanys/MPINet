package hmu.netmpea.local;

import java.util.List;

import hmu.netmpea.osem.Metabolite;
import hmu.netmpea.services.FuzzyMetaboliteConvertService;

import org.compass.core.CompassHit;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class FuzzyFindTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring/context.xml");
		FuzzyMetaboliteConvertService ser =  ctx.getBean(FuzzyMetaboliteConvertService.class);
		List<CompassHit> fuzzyResult = ser.find("galactosylceramide");
		for(CompassHit hit : fuzzyResult) {
			System.out.printf("%.4f : %s[%s]\n", hit.getScore(), ((Metabolite)hit.getData()).getName(), ((Metabolite)hit.getData()).getMetaboliteId());
		}
	}

}
