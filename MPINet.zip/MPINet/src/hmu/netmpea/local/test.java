package hmu.netmpea.local;

import hmu.netmpea.services.IDConvertService;

import java.util.Arrays;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class test {

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
/*		CIDtoOther idcon = new CIDtoOther();
		String[] risk = {"791","6106","1182","6057","6140","6262","6305","145742","6274","408","5950","107689","4277439","1061","70","441","5951","7405","985","965","5281","231","750","18230","439357","5283588","439162","439824","439285","6288","6322","847","6426853","8094","80283","305","6267","5962","790","1123","87","96","180","263","674","753","880","892","1079","1175","5756","5793","12736","20484","23976","24759","31246","61503","64960","64969","65154","92105","92135","439709","2724480"};
		System.out.println(Arrays.deepToString(idcon.convert(risk, "HMDBID")));*/
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring/context.xml");
		IDConvertService ids = ctx.getBean(IDConvertService.class);
		System.out.println("su");
	}

}
