package hmu.netmpea.local;

import hmu.netmpea.osem.initial.MetaboliteOsemInitialService;
import hmu.netmpea.services.IDConvertService;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class IndexPre {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception{
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring/context.xml");
		MetaboliteOsemInitialService ser = ctx.getBean(MetaboliteOsemInitialService.class);
		ser.initialHsqldb();
	}

}
