package hmu.netmpea.local;


import java.util.Arrays;
import org.rosuda.REngine.REXP;
import org.rosuda.REngine.REXPDouble;
import org.rosuda.REngine.REXPFactor;
import org.rosuda.REngine.REXPInteger;
import org.rosuda.REngine.REXPString;
import org.rosuda.REngine.RList;
import org.rosuda.REngine.Rserve.RConnection;

public class BasicExample {
	
	@SuppressWarnings("unused")
	public static void main(String[] args) throws Exception{
		
		RConnection c = new RConnection();
		
		//Requirement
		c.voidEval("library(\"MPEANet\")");
		
/*		//set parameters
		String[] risk = {"791","6106","1182","6057","6140","6262","6305","145742","6274","408","5950","107689","4277439","1061","70","441","5951","7405","985","965","5281","231","750","18230","439357","5283588","439162","439824","439285","6288","6322","847","6426853","8094","80283","305","6267","5962","790","1123","87","96","180","263","674","753","880","892","1079","1175","5756","5793","12736","20484","23976","24759","31246","61503","64960","64969","65154","92105","92135","439709","2724480"};
		String pathType = "KEGG";
		String method = "MPEANet";
		int annlim = 2;
		int bglim = 10;
 		//compute
		//REXP exp = c.eval("identifypathway(risk0,pss0,pathType=\"KEGG\",method=\"NetMPEA\",annlim=2,bglim=10)");
		c.assign("risk", risk);
		//connection.voidEval("risk0<-as.character(risk0[[1]])");
		c.voidEval("pss<-getPSS(risk,plot=F)");
		c.assign("pathType", pathType);
		c.assign("method", method);
		
		//build command
		//构造command。
		String command = 
				"anncpdpre<-identifypathway(" +
						"risk," +
						"pss," +
						"pathType=pathType," +
						"method=method," +
						"annlim=" + annlim + "," +
						"bglim=" + bglim;
		command+=")";
		//compute
		c.eval(command);
		String convertStr = 
			"result<-printGraph(" +
				"anncpdpre," +
				"detail=TRUE," +
				"method=method" ;
		convertStr+=")";
		REXP exp = c.eval(convertStr);*/
		
		REXP exp = c.eval("result");
		String[][] data = parseToTable(exp);
		c.close();
		
	}
	
	public static String[][] parseToTable(REXP exp) throws Exception {
		
		RList result = exp.asList();
		// fetch column names
		String[] colNames = result.keys();
		int colCount = colNames.length;
		
		// fetch data by column		
		REXP[] colValues = new REXP[colCount];
		for (int i = 0; i < colValues.length; i++) {
			colValues[i] = result.at(colNames[i]);
		}
		//fetch row number
		int rowCount = result.at(colNames[1]).length();
		String[][] data = new String[rowCount+1][colCount+1];
		
		for(int i=0; i< colCount; i++) {
			data[0][i] = colNames[i];
			System.out.print(data[0][i]);
			System.out.print("\t");
		}
		for(int j=1; j<= rowCount; j++) {
			for(int i=0; i< colCount; i++) {
				REXP tmp = colValues[i];
				if(tmp instanceof REXPFactor) {//将因子类型的colValues转换为字符串数组；
					data[j][i] = ((REXPFactor)tmp).asFactor().asStrings()[j-1];
					System.out.print(data[j][i]);
					System.out.print("\t");
				}else if(tmp instanceof REXPString){//将String类型的colValues转换为字符串数组；
					data[j][i] = ((REXPString)tmp).asStrings()[j-1];
					System.out.print(data[j][i]);
					System.out.print("\t");
				}else if(tmp instanceof REXPInteger) {//将Integer类型的colvalues转换为字符串数组；
					data[j][i] = Integer.toString(((REXPInteger)tmp).asIntegers()[j-1]);
					System.out.print(data[j][i]);
					System.out.print("\t");
				} else if(tmp instanceof REXPDouble) {//将Double类型的colValues转换为字符串数组；
					data[j][i] = String.format("%.10e", ((REXPDouble)tmp).asDoubles()[j-1]);
					System.out.print(data[j][i]);
					System.out.print("\t");
				} else {
					throw new IllegalStateException("Unhandled REXP type: \n"+tmp);
				}
				
			}
			System.out.println();
		}
		System.out.println("-------------------------------");
		System.out.println(Arrays.deepToString(data));
		return data;
	}
	
		
}
