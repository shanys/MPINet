package hmu.netmpea.local;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;



public class CIDtoOther  {
	
	
	public String[] convert(String[] risk, String dataType) throws Exception{
		
		BufferedReader br = new BufferedReader(new FileReader(new File("E:/IDmapresult.txt")));
		ArrayList<String> riskList = new ArrayList<String>();
		
		String line = br.readLine();
		//SID
		if(dataType.equals("SID")){
			Map<String, String> smap = new HashMap<String, String>();
			while(line != null && line.trim().length()>0) {
				String[] mapArray = line.split("\t");
				if(mapArray[1] != null && mapArray[1].trim().length()>0){
					String[] sArr = mapArray[1].split(";");
					for(int i=0; i<sArr.length; i++){
						smap.put(mapArray[0], sArr[i]);
					}
				}
				line = br.readLine();
			}
			
			for(String s : risk){
				if(smap.get(s) != null){
					riskList.add(smap.get(s));
				}
			}
		}
		
		//KEGGID
		if(dataType.equals("KEGGID")){
			Map<String, String> keggmap = new HashMap<String, String>();
			while(line != null && line.trim().length()>0) {
				String[] mapArray = line.split("\t");
				if(mapArray[2] != null && mapArray[2].trim().length()>0){
					String[] sArr = mapArray[2].split(";");
					for(int i=0; i<sArr.length; i++){
						keggmap.put(mapArray[0], sArr[i]);
					}
				}
				line = br.readLine();
			}
			
			for(String s : risk){
				if(keggmap.get(s) != null && !keggmap.get(s).equals("NA")){
					riskList.add(keggmap.get(s));
				}
			}
		}
		
		//CHEBIID
		if(dataType.equals("CHEBIID")){
			Map<String, String> chebimap = new HashMap<String, String>();
			while(line != null && line.trim().length()>0) {
				String[] mapArray = line.split("\t");
				if(mapArray[3] != null && mapArray[3].trim().length()>0){
					String[] sArr = mapArray[3].split(";");
					for(int i=0; i<sArr.length; i++){
						chebimap.put(mapArray[0], sArr[i]);
					}
				}
				line = br.readLine();
			}
			
			for(String s : risk){
				if(chebimap.get(s) != null && !chebimap.get(s).equals("NA")){
					riskList.add(chebimap.get(s));
				}
			}
		}
		
		//CHEMBLID
		if(dataType.equals("CHEMBLID")){
			Map<String, String> chemblmap = new HashMap<String, String>();
			while(line != null && line.trim().length()>0) {
				String[] mapArray = line.split("\t");
				if(mapArray[4] != null && mapArray[4].trim().length()>0){
					String[] sArr = mapArray[4].split(";");
					for(int i=0; i<sArr.length; i++){
						chemblmap.put(mapArray[0], sArr[i]);
					}
				}
				line = br.readLine();
			}
			
			for(String s : risk){
				if(chemblmap.get(s) != null && !chemblmap.get(s).equals("NA")){
					riskList.add(chemblmap.get(s));
				}
			}
		}
		
		//HMDBID
		if(dataType.equals("HMDBID")){
			Map<String, String> hmdbmap = new HashMap<String, String>();
			while(line != null && line.trim().length()>0) {
				String[] mapArray = line.split("\t");
				if(mapArray[5] != null && mapArray[5].trim().length()>0){
					String[] sArr = mapArray[5].split(";");
					for(int i=0; i<sArr.length; i++){
						hmdbmap.put(mapArray[0], sArr[i]);
					}
				}
				line = br.readLine();
			}
			
			for(String s : risk){
				if(hmdbmap.get(s) != null  && !hmdbmap.get(s).equals("NA")){
					riskList.add(hmdbmap.get(s));
				}
			}
		}

		br.close();
		return riskList.toArray(new String[0]);
	}
}
