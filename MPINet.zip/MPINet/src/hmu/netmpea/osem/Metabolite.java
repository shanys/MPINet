package hmu.netmpea.osem;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.compass.annotations.Index;
import org.compass.annotations.Searchable;
import org.compass.annotations.SearchableId;
import org.compass.annotations.SearchableProperty;

@Searchable
@Entity
@Table(uniqueConstraints={
		@UniqueConstraint(columnNames={"name","metaboliteId"})
})
public class Metabolite {

	@SearchableId
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	@SearchableProperty
	@Column(length=1100)
	private String name;
	
	@SearchableProperty(index=Index.NO)
	@Column(length=10)
	private String metaboliteId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMetaboliteId() {
		return metaboliteId;
	}

	public void setMetaboliteId(String metaboliteId) {
		this.metaboliteId = metaboliteId;
	}
}
