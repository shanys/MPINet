package hmu.netmpea.osem.initial;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.h2.tools.Server;
import org.springframework.stereotype.Service;

@SuppressWarnings("unused")
public class H2ServerInitialService {

	private Server server;
	
	@PostConstruct
	public void startServer() throws Throwable {
		server = Server.createTcpServer().start();
		
	}
	
	@PreDestroy
	public void stopServer() throws Throwable{
		if(server != null)
			server.stop();
	}

}
