package hmu.netmpea.osem.initial;

import hmu.netmpea.osem.Metabolite;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@SuppressWarnings("unused")
public class MetaboliteOsemInitialService {

	@PersistenceContext
	private EntityManager entityManager;
	
	private static Logger logger = LoggerFactory.getLogger(MetaboliteOsemInitialService.class);
	
	private Set<String> entries = new HashSet<String>();
	
	@Transactional
	public void initialHsqldb() throws Exception{
		logger.info("Begin to initialize Metabolite Names. . . ");
		
		Resource resource = new ClassPathResource("IDmapresult.txt");
		BufferedReader br = new BufferedReader(new InputStreamReader(resource.getInputStream()));
		String line = br.readLine();
		line = br.readLine();
		while(line != null && line.trim().length()>0) {
			String[] tokens = line.split("\t");
			String cid = tokens[0];
			String[] names = tokens[6].split(";");
			for(String name : names) {
				if(name == null || name.trim().length()==0) continue;
				if(entries.contains(cid+name)) continue;
				
				Metabolite m = new Metabolite();
				m.setMetaboliteId(cid);
				m.setName(name);
				entityManager.persist(m);
				
				entries.add(cid+name);
			}
			line = br.readLine();
		}
		br.close();
		logger.info("Metabolite Names Initialization Complated.");
		System.out.println("Metabolite Names Initialization Complated.");
	}
}
