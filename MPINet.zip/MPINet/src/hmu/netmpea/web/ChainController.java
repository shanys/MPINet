package hmu.netmpea.web;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Version:  1.0
 * JDK version used: jdk1.6
 * @author yhx
 * Create Date： 2013.03.03 
 * Comments: 根据输入dataType判断执行什么操作，CID直接执行R程序；其他ID，进行ID转换；MetaboliteName需进行模糊查询。次类为测试类，用于测试接受参数和页面跳转
 * 测试类，不用session存参数，跳转的时候用request传参。
 */
@Controller
public class ChainController {

	@RequestMapping(
			value="chain/index",
			method=RequestMethod.GET)
	public void index(HttpServletRequest request, HttpServletResponse response) throws Throwable {
		request.setAttribute("arg1", "Hello");
		request.getRequestDispatcher("next").forward(request, response);
	}

	@RequestMapping(
			value="next")
	public void next(HttpServletRequest request, HttpServletResponse response) throws Throwable {
		request.setAttribute("arg2", "World");
		request.getRequestDispatcher("last").forward(request, response);
	}
	
	@RequestMapping(
			value="chain/last")
	public void last(HttpServletRequest request, HttpServletResponse response, PrintWriter out) throws Throwable {
//	public String last(Model model, PrintWriter out) {你返回视图得用String， 我测试就用void了
		out.printf("%s %s\n", request.getAttribute("arg1"), request.getAttribute("arg2"));
	}
}
