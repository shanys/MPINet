package hmu.netmpea.web;

import hmu.netmpea.services.IDConvertService;
import hmu.netmpea.services.NetMPEAService;
import hmu.netmpea.services.ParameterConvertService;
import hmu.netmpea.web.NetMPEAController;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;


@Controller
public class NetMPEAController {

	private static Logger logger = LoggerFactory.getLogger(NetMPEAController.class);
	
	@Autowired
	private NetMPEAService netMPEAService;
	
	@Autowired
	private ParameterConvertService parameterConvertService;
	
	@Autowired
	private IDConvertService idConvertService;
	
	@RequestMapping(
			value="index",
			method=RequestMethod.GET)
	public String form(Model model) throws Exception{
		return "form";
	}
	
	
	@RequestMapping(
			value="convert")
	public String convert(
			@RequestParam String pathType,
			@RequestParam String method,
			@RequestParam int annlim,
			@RequestParam int bglim,
			
			@RequestParam String dataType, //用于判断输入的risk是什么类型的数据，CID直接计算；SID、KEGGID、CHEBIID、CHEMBLID、HMDBID则执行IDConvert；metaboliteName执行模糊查询
			@RequestParam(required=false) String risk,
			@RequestParam(required=false) MultipartFile riskByFile,
			Model model,
			HttpSession session) throws Throwable {
		
			session.setAttribute("fuzzy", null);
		
			//应加入参数是否符合的逻辑校验功能
			
			//参数转换部分，主要转换的是从页面传入的大文本，即risk。
			String[] riskArr = null;  //用户输入的种子
			
			if(riskByFile != null) {
				riskArr = parameterConvertService.convert(riskByFile);
				//bug fix #1
				//防止发生选择文件后将文件删除再使用textarea会屏蔽textarea数据的问题。
				if(riskArr.length <= 0) {
					riskArr = parameterConvertService.convert(risk);
				}
			}else{
				riskArr = parameterConvertService.convert(risk);
			}
			
			//将输入所有dataType的risk转换成CID
			String[] cidArr = null;  
			ArrayList<String> idList = new ArrayList<String>();
			String returnStr = null;
			
			//将参数值赋给session，供下一次mapping存取
/*			request.setAttribute("pathType", pathType);
			request.setAttribute("method", method);
			request.setAttribute("annlim", annlim);
			request.setAttribute("bglim", bglim);
			request.setAttribute("dataType", dataType);*/
			
			session.setAttribute("pathType", pathType);
			session.setAttribute("method", method);
			session.setAttribute("annlim", annlim);
			session.setAttribute("bglim", bglim);
			session.setAttribute("dataType", dataType);
			
			if(dataType.equals("CID")){
				cidArr = riskArr;
				session.setAttribute("cidArr", cidArr);
				for(int i=0; i<riskArr.length; i++){
					idList.add(riskArr[i]);
				}
				session.setAttribute("idList", idList);
				returnStr = "execute";
				//request.getRequestDispatcher("execute").forward(request, response);
			}else if (dataType.equals("metaboliteName")){
				//执行模糊查询
				session.setAttribute("riskArr", riskArr);
				returnStr = "mapping";
				//request.getRequestDispatcher("mapping").forward(request, response);
			}else {
				//执行ID转换
				idList = idConvertService.convert(riskArr, dataType);//输入ID，转换后的CID
				session.setAttribute("idList", idList);
				cidArr = idConvertService.listToArray(idList);
				session.setAttribute("cidArr", cidArr);
				returnStr = "execute";
				//request.getRequestDispatcher("execute").forward(request, response);
			}
			
			return "redirect:/"+returnStr;
	}
	
	@RequestMapping(
			value="execute")
	public String execute(
			Model model,
			HttpServletRequest request,
			HttpServletResponse response,
			HttpSession session) throws Exception {
		String[] riskArr = (String[]) session.getAttribute("cidArr");
		String pathType = (String) session.getAttribute("pathType");
		String method = (String) session.getAttribute("method");
		int annlim = (Integer) session.getAttribute("annlim");
		int bglim = (Integer) session.getAttribute("bglim");
		@SuppressWarnings("unchecked")
		List<String> idList =  (List<String>) session.getAttribute("idList");
		
		//判断输入的risk匹配到CID后是否为空
		List<String> message = new ArrayList<String>();
		if(riskArr == null || riskArr.length == 0) {
			message.add("risk you input have no matches.");
		}
		if(message.size() > 0) {
			model.addAttribute("message", message);
			//request.getRequestDispatcher("error").forward(request, response);
			return "error";
		}
		
		//日志部分，请保留，调试使用
		//如需关闭日志，请修改/resources/log4j.xml
		logger.debug("[pathType]"+pathType);
		logger.debug("[method]"+method);
		logger.debug("[annlim] "+annlim);
		logger.debug("[bglim] "+bglim);		
		logger.debug("[risk]"+riskArr);
		
		String[][] data = netMPEAService.execute(riskArr, pathType, method, annlim, bglim);

		model.addAttribute("risk",riskArr);
		model.addAttribute("pathType",pathType);
		model.addAttribute("method", method);
		model.addAttribute("annlim",annlim);
		model.addAttribute("bglim",bglim);
		model.addAttribute("data", data);
		model.addAttribute("rowCount", data.length);
		model.addAttribute("colCount", data[0].length);
		
		session.setAttribute("data", data);
		session.setAttribute("riskList", idList);
		
		return "result";
	}

	@RequestMapping(
			value="mapping")
	public String mapping(Model model, HttpSession session) throws Exception {
		String[] riskArr = (String[]) session.getAttribute("riskArr");
		String[][] fuzzyMapping = null;
		fuzzyMapping = (String[][]) session.getAttribute("fuzzy");
		if(fuzzyMapping == null)
			fuzzyMapping = idConvertService.fuzzyFind(riskArr);
		session.setAttribute("fuzzy", fuzzyMapping);
		//System.out.println(Arrays.deepToString(fuzzyMapping));
		return "mapping";
	}
	
	@RequestMapping(
			value="fuzzyDetails")
	public String fuzzyDetails(
			@RequestParam String risk, 
			Model model, 
			HttpSession session) throws Exception {
		String[][] fuzzyDetails = idConvertService.fuzzyDetail(risk);
		model.addAttribute("fuzzyDetails", fuzzyDetails);
		//System.out.println(Arrays.deepToString(fuzzyDetails));
		return "details";
	}
	
	@RequestMapping(
			value="backtoMapping")
	public String findFuzzy(
			@RequestParam String fuzzyMatch, 
			Model model, 
			HttpSession session) throws Exception {
		String[][] fuzzyMapping = (String[][]) session.getAttribute("fuzzy");
		String[] fuzzyMatches = fuzzyMatch.split(";");
		//System.out.println("lalal--"+fuzzyMatches[0]);
		for(int i=0;i<fuzzyMapping.length;i++){
			if(fuzzyMapping[i][0].equals(fuzzyMatches[0])){
				fuzzyMapping[i][1] = fuzzyMatches[1];
				fuzzyMapping[i][2] = fuzzyMatches[2];
				fuzzyMapping[i][3] = "1";
			}
		}
		return "redirect:/mapping";
	}
	
	@RequestMapping(
			value="submit")
	public String submit(
			Model model, 
			HttpSession session) throws Exception {
		
		ArrayList<String> idList = new ArrayList<String>();
		String[][] fuzzyMapping = (String[][]) session.getAttribute("fuzzy");
		for(int i=0;i<fuzzyMapping.length;i++){
			if(!fuzzyMapping[i][3].equals("0")){
				idList.add(fuzzyMapping[i][0]+"\t"+fuzzyMapping[i][1]+"\t"+fuzzyMapping[i][2]);
			}
		}
		String[] cidArr = new String[idList.size()];
		for(int j=0; j<idList.size(); j++){
			cidArr[j] = idList.get(j).split("\t")[2];
		}
		session.setAttribute("idList", idList); //放在mapping页面提交的时候再赋值
		session.setAttribute("cidArr", cidArr);
		System.out.println(Arrays.deepToString(cidArr));
		return "redirect:/execute";
	}
	
	@RequestMapping(
			value="download_data",
			method=RequestMethod.GET)
	public void download(HttpSession session, HttpServletResponse response) throws Exception{
		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename=result.csv");
		PrintWriter out = response.getWriter();
		String[][] data = (String[][]) session.getAttribute("data");
		for(String[] line : data) {
			String lineOut = StringUtils.join(line, ",", 0, line.length);
			out.println(lineOut);
		}
		out.flush();
	}
	
	@RequestMapping(
			value="download_risk",
			method=RequestMethod.GET)
	public void downloadSeeds(HttpSession session, HttpServletResponse response) throws Exception{
		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename=risk.txt");
		PrintWriter out = response.getWriter();
		@SuppressWarnings("unchecked")
		ArrayList<String> riskList = (ArrayList<String>) session.getAttribute("riskList");
		for(String line :  riskList){
			out.println(line);
		}
		out.flush();
	}
	

}
